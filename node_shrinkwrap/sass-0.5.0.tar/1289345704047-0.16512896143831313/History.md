
0.5.0 / 2010-10-26 
==================

  * Added Chris Pickel as contributor
  * Added support substitution in variable declarations [Chris Pickel]
  * Added npm support
  * Fixed mixins [Chris Pickel]

0.4.2 / 2010-06-21
==================

  * Added lib directory to package.json for npm to work

0.4.1 / 2010-06-21
==================

  * Addex index.js for npm support

0.4.0 / 2010-04-02
==================

  * Added "cache" option

0.3.0 / 2010-02-22
==================

  * Added mixin support. Closes #1

0.2.0 / 2010-02-05
==================

  * Added alternate variable syntax back ("var: val")
  * Added a method to extract variables. Closes #3

0.1.0 / 2010-02-05
==================

  * Added continuation support. Closes #15

0.0.2 / 2010-02-02
==================

  * Fixed complex selectors
  * Removed "var: val" syntax for variables

0.0.1 / 2010-01-12
==================

  * Initial release
